@echo -off 
for %a run (0 15 1) 
  if exist fs%a:ZW-BI-10.5-S105ALWR120-S1235U-ZW-B-159-G-0403.bin then  
     fs%a:  
     Fpt.efi -f ZW-BI-10.5-S105ALWR120-S1235U-ZW-B-159-G-0403.bin -y
  endif  
endfor  
