echo -off
for %i in fs0 fs1 fs2 fs3 fs4 fs5 fs6
        if exist %i:\STARTUP.NSH then 
            %i:
            cd AutoFlash
            FptFlashBios.nsh
            echo  timeout 3s
            stall 30000
            FEC64.nsh
            goto EOF                
        else
            echo not find %i:\STARTUP.NSH
        endif
endfor
:EOF
reset -s
